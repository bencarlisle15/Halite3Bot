
// This Java API uses camelCase instead of the snake_case as documented in the API docs.
//	 Otherwise the names of methods are consistent.

import hlt.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;

public class MyBot {
	public static void main(final String[] args) {
		final long rngSeed;
		if (args.length > 1) {
			rngSeed = Integer.parseInt(args[1]);
		} else {
			rngSeed = System.nanoTime();
		}
//		final Random rng = new Random(rngSeed);
		Game game = new Game();
		// At this point "game" variable is populated with initial map data.
		// This is a good place to do computationally expensive start-up pre-processing.
		// As soon as you call "ready" function below, the 2 second per turn timer will
		// start.

		// THIS IS FOR METHOD 2
		SortedArrayList<Cluster> clusters = game.gameMap.updateClusters(game.me);
		HashMap<Ship, Cluster> jobs = new HashMap<Ship, Cluster>();

		game.ready("MyJavaBot");

		Log.log("Successfully created bot! My Player ID is " + game.myId + ". Bot rng seed is " + rngSeed + ".");
		for (;;) {
			game.updateFrame();
			final Player me = game.me;
			final GameMap gameMap = game.gameMap;
			final ArrayList<Command> commandQueue = new ArrayList<Command>();
			final HashMap<Ship, Position> nextPositions = new HashMap<Ship, Position>();
			for (Ship ship : me.ships.values()) {
				if (!jobs.containsKey(ship)) {
					for (Cluster cluster : clusters) {
						if (!cluster.hasWorker()) {
							cluster.setWorker(ship);
							jobs.put(ship, cluster);
							break;
						}
					}
				}
				if (jobs.get(ship) == null) {
					clusters = gameMap.updateClusters(me);
					for (Cluster cluster : clusters) {
						if (!cluster.hasWorker()) {
							cluster.setWorker(ship);
							jobs.put(ship, cluster);
							break;
						}
					}
					if (jobs.get(ship) == null) {
						continue;
					}
				}
				Log.log("Cluster at : " + jobs.get(ship).center);
				Position nextPosition;
				if (ship.halite > 900 || ship.isFull()) {
					nextPosition = me.shipyard.position;
				} else if (gameMap.at(ship.position).halite > GameMap.stopEating || gameMap.at(ship.position).halite * 0.1 > ship.halite || ship.halite - gameMap.at(ship.position).halite*0.1 <= 900 && ship.halite > 900) {
					nextPosition = ship.position;
				} else {
					nextPosition = jobs.get(ship).getNextPosition(ship, gameMap);
				}
				Log.log("Going to " + nextPosition);
				
				if (nextPosition == null) {
					jobs.remove(ship);
					nextPosition = me.shipyard.position;
				}
				Direction nextDirection = gameMap.navigate(ship, nextPosition, nextPositions, me.ships.values());
				Position adjacentPosition = gameMap.getPositionFromDirection(ship.position, nextDirection);
				nextPositions.put(ship, adjacentPosition);
				Log.log("Size: " + nextPositions.size());
				commandQueue.add(ship.move(nextDirection));
			}
			String ans = "END: ";
			for (Ship s: nextPositions.keySet()) ans += s.id.id + " at " + s.position + " going to " + nextPositions.get(s) + ",";
			Log.log(ans);
			for (Command c : commandQueue) {
				Log.log(c.command);
			}
//			if (game.turnNumber <= 200 && me.halite / 4 >= Constants.SHIP_COST && !gameMap.at(me.shipyard).isOccupied() || me.ships.size() == 0) {
			if (me.ships.size() <= 1) {
				commandQueue.add(me.shipyard.spawn());
			}

			game.endTurn(commandQueue);
		}
	}

	private static boolean isDeadLock(Ship ship, Position nextPosition, Player me, ArrayList<Command> commandQueue,
			GameMap gameMap) {
		for (Command c : commandQueue) {
			String[] splitCommands = c.command.split(" ");
			if (!splitCommands[0].equals("m")) {
				continue;
			}
			Ship s = me.ships.get(new EntityId(Integer.parseInt(splitCommands[1])));
			Position nextSPosition = gameMap.getPositionFromDirection(s.position,
					getDirectionFromLetter(splitCommands[2]));
			if (s.position.equals(nextPosition) && nextSPosition.equals(ship.position)) {
				return true;
			}
		}
		return false;
	}

	private static Direction getDirectionFromLetter(String str) {
		switch (str) {
		case "n":
			return Direction.NORTH;
		case "w":
			return Direction.WEST;
		case "s":
			return Direction.SOUTH;
		case "e":
			return Direction.EAST;
		default:
			return Direction.STILL;
		}
	}

	private static String listToString(Object[] objects) {
		String ans = "";
		for (Object o : objects) {
			String oStr = "null";
			if (o != null) {
				oStr = o.toString();
				if (o instanceof Ship) {
					oStr = String.valueOf(((Ship) o).id);
				} else if (o instanceof Position) {
					oStr = ((Position) o).x + ":" + ((Position) o).y;
				}
			}
			ans += oStr + ", ";
		}
		return ans;
	}

	private static ArrayList<Ship> clone(Collection<Ship> values) {
		ArrayList<Ship> ships = new ArrayList<Ship>();
		for (Ship s : values) {
			ships.add(s);
		}
		return ships;
	}

	@SuppressWarnings("unused")
	private static ArrayList<Command> method1(Game game, GameMap gameMap, Player me) {
		ArrayList<Command> commandQueue = new ArrayList<Command>();
		game.updatePriorityMap();
		Collection<Ship> remainingShips = clone(me.ships.values());
		ArrayList<Position> nextPositions = new ArrayList<Position>();
		ArrayList<Position> nextDirectionPositions = new ArrayList<Position>();
		SortedArrayList<PriorityMapCell> map = game.priorityMap;
		for (Ship ship : me.ships.values()) {
			if (ship.halite > 900 || ship.isFull()) {
				Position closestDropoffPosition = me.shipyard.position;
				for (Dropoff dropoff : me.dropoffs.values()) {
					if (dropoff == null || gameMap.calculateDistance(ship.position, dropoff.position) < gameMap
							.calculateDistance(ship.position, closestDropoffPosition)) {
						closestDropoffPosition = dropoff.position;
					}
				}
				Direction newDirection = gameMap.naiveNavigate(ship, closestDropoffPosition);
				Position nextPosition = gameMap.getPositionFromDirection(ship.position, newDirection);
				if (nextDirectionPositions.contains(nextPosition)) {
					continue;
				}
				commandQueue.add(ship.move(newDirection));
				nextDirectionPositions.add(nextPosition);
				remainingShips.remove(ship);
			}
		}
		for (PriorityMapCell cell : map) {
			Position newPosition = new Position(cell.row, cell.column);
//			Log.log(cell.toString() + " :: " + gameMap.at(newPosition).halite);
			if (nextPositions.contains(newPosition) || !remainingShips.contains(cell.nearestShip)) {
				continue;
			} else if (cell.nearestShip.position.equals(newPosition)) {
				if (nextDirectionPositions.contains(newPosition)) {
					continue;
				}
				commandQueue.add(cell.nearestShip.stayStill());
				remainingShips.remove(cell.nearestShip);
				nextPositions.add(newPosition);
				nextDirectionPositions.add(newPosition);

			} else {
				Direction newDirection = gameMap.naiveNavigate(cell.nearestShip, newPosition);
				Position nextPosition = gameMap.getPositionFromDirection(cell.nearestShip.position, newDirection);
				if (nextDirectionPositions.contains(nextPosition)) {
					continue;
				}
				commandQueue.add(cell.nearestShip.move(newDirection));
				remainingShips.remove(cell.nearestShip);
				nextPositions.add(newPosition);
				nextDirectionPositions.add(nextPosition);
			}
		}
		for (final Ship ship : remainingShips) {
			if (ship.position.equals(game.me.shipyard.position) || nextDirectionPositions.contains(ship.position)) {
				int positionX = ship.position.x;
				int positionY = ship.position.y;
				Direction direction = Direction.SOUTH;
				Position nextPosition = new Position(positionX, positionY - 1);
				if (!nextDirectionPositions.contains(new Position(positionX + 1, positionY))) {
					direction = Direction.EAST;
					nextPosition = new Position(positionX + 1, positionY);
				} else if (!nextDirectionPositions.contains(new Position(positionX, positionY + 1))) {
					direction = Direction.NORTH;
					nextPosition = new Position(positionX, positionY + 1);
				} else if (!nextDirectionPositions.contains(new Position(positionX - 1, positionY))) {
					direction = Direction.WEST;
					nextPosition = new Position(positionX - 1, positionY);
				} else {
					Log.log("I HAVE NOTHING TO DO");
				}
				commandQueue.add(ship.move(direction));
				nextDirectionPositions.add(nextPosition);
			} else {
				commandQueue.add(ship.stayStill());
				nextDirectionPositions.add(ship.position);
			}
		}
		return commandQueue;
	}
}
